/**
 //@FileName    :cam.c
 //@CreatedDate :2021年12月22日
 //@Author      :LiHao
 //@Description :
**/

#include "cam.h"

/***********************************************************************
    (1)采用4邻域找到左右边界,<记录扫线的趋势,边缘延伸的方向>
    (2)记录每行的左右修复以及未修复边界,扫出修复未修复中线,
    第一次丢失 第一次正常 第二次丢失 第二次正常计算每行斜率,丢线状态
    (3)<单独记录部分行之间的线状态>
    (3)<元素判断 直道-弯道-坡道-十字-三岔-车库-环岛>
    (4)<根据元素修复中线边线>
    (5)计算中线
************************************************************************/

/***************************程序索引(ctrl + G跳转)*********************
    (1)总的标志初始化      ------------------------------------     70
    (2)两点补线             ------------------------------------    115
    (3)边缘搜索             ------------------------------------    340
    (4)特殊元素             ------------------------------------    780
    (5)直道判别             ------------------------------------    810
    (6)弯道判别             ------------------------------------    880
    (7)三岔判别             ------------------------------------   1000
    (8)三岔补线             ------------------------------------   1050
    (9)车库判别             ------------------------------------   1200
    (10)车库补线            ------------------------------------   1250
    (11)环岛判别            ------------------------------------   1500
    (12)环岛补线            ------------------------------------   1500
    (13)坡道判别            ------------------------------------   1870
    (14)十字判别            ------------------------------------   1950
    (15)十字补线            ------------------------------------   2000
*********************************************************************/

//直道赛道宽度
//const uint8 RoadWide[ROW] =
//{
//    128,128,128,128,128,127,125,123,121,120,
//    119,117,116,114,112,110,108,107,105,103,
//    101,99,97,95,94,92,90,88,86,84,
//    83,80,78,76,74,72,70,68,67,65,
//    63,61,59,57,55,53,52,51,50,47,
//    45,43,42,39,37,36,34,32,30,28,
//};
const int8_t CenterCalAry[16] = //dy:0-15//+3+2
        {
                27 , 30 , 34 , 36 , 43 ,
                50 , 55 , 62 , 69 , 76 ,
                83 , 90 , 97 ,105 ,112 ,119
        };



BaseTypedef     Base;
int16           Xsite = 0;//当前扫线X坐标
int16           Ysite = 0;//当前扫线Y坐标
ImageDealType   Img;
LineStatusType  LineALL,Line5_35,Line30_60;
ColumnTypedef   Column10,Column117,Column64;
//---------------------------------清除行状态计数函数--------------------------//
void LineStatusClear(LineStatusType *Line)
{
    Line->AllNormal = 0;
    Line->AllLose = 0;
    Line->LeftNormal = 0;

    Line->RightNormal = 0;
    Line->LeftLose = 0;
    Line->RightLose = 0;
    Line->LeftLoseRightNormal = 0;
    Line->LeftNormalRightLose = 0;
}

//----------------------标志初始化(在bsp_init初始化一次)-------------------//
void ImageProcessingStatusInit(void)
{
    //----------------------------BASE----------------------------------//
    Base.Topline = ROW - 1;
    Base.ToplineTemp = ROW -1;
    Base.ToplineFindFlag = 'T';
//    LineStatusClear(&LineALL);
//    LineStatusClear(&Line5_35);
//    LineStatusClear(&Line30_60);
    Base.element_check = 'T';
    //元素标志初始化
    //straight
    Straight.Beep = 'F';
    Straight.FindFlag = 'F';
    //curve
    Curve.Beep = 'F';
    Curve.FindFlag = 'F';
//    //fork
    Fork.FindFlag = 'F';
//    Fork.Peak.x = 0;
//    Fork.Peak.y = 0;
    Fork.StartLine = 0;
    Fork.In_Direct = 'R';
    Fork.state = ForkOut;
    Fork.InDis = 0.0f;
    Fork.ForkNum = 1;
    Fork.ForkLenth = 1.0f;
//    Fork.TurnInK = 0;
//    Fork.TurnOutK = 0;
//    Fork.ForkAmount = 2;
//    Fork.OutSpeed = 180;
//    Fork.InSpeed = 240;
    //Barn
    Barn.FindFlag = 'F';
    Barn.OutDir = 'R';//出库方向
    Barn.state = BarnStart;//初始时车库状态//初始为BarnStart
//    Barn.BarnFoundELCSum14Min = 10;
    Barn.BarnNum = 0;//当前经过的车库数//初始化为0
    Barn.BranInNum = 1;//第几次经过车库时进入
    Barn.BarnInTime = 9999999.99f;
//    Barn.BarnFindDis = 0;
//    Barn.BarnLength = 0.6f;
//    Barn.BarnInStraightSpeed = 230;
//    Barn.BarnInDistanceCount = 0.0;
//    Barn.StartLineFoundY = 20;//起始搜索行
//    Barn.BarnTurnCenter = 150;
//    Barn.BarnTurnSpeed = 230;
//    Barn.BarnInRunDis = 0.30;

    //Circle
    Circle.FindFlag = 'F';
    Circle.state = CircleOut;
//    Circle.RoundCenterY = 0;
//    Circle.CircleNum = 0;//当前环岛个数
//    //
//    Circle.CircleAmount = 2;//环岛总数
//    Circle.DontELCJudgeDis = 1.0;//出环不电磁判别环岛距离
//    Circle.CircleELC14 = 140;//ELC14判别环岛
//    Circle.CircleELC23 = 0;
//    Circle.FoundOutSpeed = 240;
//    //Ramp
    Ramp.FindFlag = 'F';
//    Ramp.MayRampGyroYMax = 100;
//    Ramp.MayRampDis = 0;
//    Ramp.MayRampFlag = 'F';
//    Ramp.MayRampFlagClearDis = 0.3;
//    Ramp.UpRampDis = 0;
//    Ramp.RampLegth = 1.0;
//    Ramp.State = EndRamp;
//    Ramp.RecoverDis = 1.0;
//    Ramp.RecoverFlag = 'F';
//    Ramp.DontJudgeRampDis = 0;
    //Cross
    Cross.FindFlag = 'F';
    Cross.state = CrossEnd;
    Cross.CrossLength = 0.5;
}


//布尔数值范围判断
bool InRange(int32 x,int32 _min,int32 _max)
{
    if(x <= _max && x >= _min)
        return 1;
    else
        return 0;
}


//两点之间补线
uint8 TwoPoint_AddingLine(uint8 x1,uint8 y1,uint8 x2,uint8 y2,int16 *p,uint8 StopYsite)
{
    int16 i = 0;
    float k = 0.000f,b = 0.000f;
    //是否补竖直线
    if(x1 == x2)
    {
        if(StopYsite >= max_ab(y1,y2))//向上补线
        {
            for(i = min_ab(y1,y2);i < StopYsite;i ++)
            {
                *p = x1;
                p ++;
            }
        }
        else if(StopYsite > min_ab(y1,y2))//下
        {
            for(i = max_ab(y1,y2);i > StopYsite;i --)
            {
                *p = x1;
                p --;
            }
        }
        else if (StopYsite == 0) {
            for (i = min_ab(y1,y2); i <= max_ab(y1,y2); i++) {
                *p = x1;
                p++;
            }
        }
        return 1;
    }
    else//计算K补线
    {
        //计算直线 y = kx + b
        k = (float)(y2 - y1) / (float)(x2 - x1);
        b = (float)(y1 - k*x1);
        if(StopYsite >= max_ab(y1,y2))//向上补线
        {
            for(i = min_ab(y1,y2);i < StopYsite;i ++)
            {
                *p = (uint8)((float)(i - b) / k);
                p ++;
            }
        }
        else if(StopYsite > min_ab(y1,y2))//下
        {
            for(i = max_ab(y1,y2);i > StopYsite;i --)
            {
                *p = (uint8)((float)(i - b) / k);
                p --;
            }
        }
        else if(StopYsite == 0)//直接进行两点补线 方向是从下往上
        {
            for(i = min_ab(y1,y2);i < max_ab(y1,y2);i ++)
            {
                *p = (uint8)((float)(i - b) / k);
                p ++;
            }
        }
        return 1;
    }
}





//边缘计数 统计不同行的边界状态
void LineBorderStateCount(void)
{
    //左右均有边线
    if(Img.LeftBorderFindFlag[Ysite] == 'T' && Img.RightBorderFindFlag[Ysite] == 'T')
    {
        LineALL.AllNormal ++;
        LineALL.LeftNormal ++;
        LineALL.RightNormal ++;
    }
    //左边有右边丢失
    if(Img.LeftBorderFindFlag[Ysite] == 'T' && Img.RightBorderFindFlag[Ysite] == 'F')
    {
        LineALL.LeftNormalRightLose ++;
        LineALL.LeftNormal ++;
        LineALL.RightLose ++;
    }
    //左边丢失右边有
    if(Img.LeftBorderFindFlag[Ysite] == 'F' && Img.RightBorderFindFlag[Ysite] == 'T')
    {
        LineALL.LeftLoseRightNormal ++;
        LineALL.LeftLose ++;
        LineALL.RightNormal ++;
    }
    //均丢失
    if(Img.LeftBorderFindFlag[Ysite] == 'F' && Img.RightBorderFindFlag[Ysite] == 'F')
    {
        LineALL.AllLose ++;
        LineALL.LeftLose ++;
        LineALL.RightLose ++;
    }
}


/**
*@Name          :ScanBorderStateReset
*@Description   :扫线状态重置
*@Param         :None
*@Return        :NULL
*@Sample        :ScanBorderStateReset();
**/
void ScanBorderStateReset(void)
{
    //-------------------Base---------------------//
    Base.firstleftnormal.y = 0;
    Base.firstleftnormal.x = 0;
    Base.firstrightnormal.y = 0;
    Base.firstrightnormal.x = 0;
    Base.firstleftlose.y = 0;
    Base.firstleftlose.x = 0;
    Base.firstrightlose.y = 0;
    Base.firstrightlose.x = 0;
    Base.ToplineTemp = 0;
    Base.ToplineFindFlag = 'F';
    Base.firstroadnormal = NoneFirstRoadNormal;
    Base.firstroaderror = 0;
    Base.LoseRoadLine = ROW - 1;
}uint8 GetBorder(void)
{
    bool error_right_flag = 0, error_left_flag = 0;
    int error_right_tmp = 0, error_left_tmp = 0;
    ScanBorderStateReset();
    //根据八领域扫线得到的边界和边界标志位信息扫线
    for(Ysite = StartScanRow;Ysite < ROW;Ysite ++)
    {

        if(Img.RoadWide[Ysite] < RoadWide0 - 15 && Base.ToplineFindFlag == 'F'){
            Base.ToplineTemp = Ysite;
            Base.ToplineFindFlag = 'T';
        }
        if(Ysite == ROW - 1 && Base.ToplineFindFlag == 'F'){
            Base.ToplineTemp = ROW - 1;
        }
        Base.LoseRoadLine = max_py;
    }
    Base.Topline = Base.ToplineTemp;//最终顶线更新

    return 1;
}
/**
* @brief    元素判断和处理
* @param    None
* @return   0
* @Sample   ElementProcessing();
**/
uint8 ElementProcessing(void)
{
}



//------------------------------------------直道----------------------------------------//
StraightTypedef Straight;


//直道识别
uint8 StrightJudge(void)
{

}


//--------------------------------------------弯道------------------------------------------//
CurveTypedef    Curve;


//判断
uint8 CurveJudge(void)
{

}


//------------------------------------------三岔----------------------------------------/
ForkTypedef  Fork;


//寻找上拐点 满足条件会返回1 找不到上拐点返回0
uint8 ForkCheckPeakPiont(void)
{
    uint8 ForkScanStartCol = CenterCol;
    uint8 ForkRoadErrorCnt = 0;
    if (Base.firstroaderror <= RoadWide0 && Base.LoseRoadLine >= ROW - 10) {
        //路宽不正常且有丢线计数
        for (Ysite = Base.firstroaderror; Ysite < Base.firstroaderror + RoadWide0; Ysite++) {
            if (Img.RoadWide[Ysite] >= RoadWide0*4/3 && \
                (Img.LeftBorderFindFlag[Ysite] == 'F' || Img.RightBorderFindFlag[Ysite] == 'F'))
                ForkRoadErrorCnt++;
            if (ForkRoadErrorCnt >= RoadWide0*2/3)
                break;
        }
    }
    if (ForkRoadErrorCnt >= RoadWide0*2/3) {//从黑色部分中线向两边扫线，扫到白色截止，作为三叉的内边界
        for (Ysite = Base.firstroaderror + RoadWide0*4/3; Ysite >= Base.firstroaderror; Ysite--) {
            if (ImageUsed[ROW - 1 - Ysite][ForkScanStartCol] == BlackPoint) {
                //向左扫线
                for (Xsite = ForkScanStartCol; Xsite >= LOutBorderCol; Xsite--) {
                    if (ImageUsed[ROW - 1 - Ysite][Xsite] == WhitePoint || Xsite == 0) {
                        Fork.ForkLeftBorder[Ysite] = Xsite;
                        break;
                    }
                }
                //向右扫线
                for (Xsite = ForkScanStartCol; Xsite <= ROutBorderCol; Xsite++) {
                    if (ImageUsed[ROW - 1 - Ysite][Xsite] == WhitePoint || Xsite == COL - 1) {
                        Fork.ForkRightBorder[Ysite] = Xsite;
                        break;
                    }
                }
                //更新扫线起始列
                ForkScanStartCol = (Fork.ForkLeftBorder[Ysite] + Fork.ForkRightBorder[Ysite])/2;
                if ((Fork.ForkRightBorder[Ysite] - Fork.ForkLeftBorder[Ysite]) <= 2) {
                    Fork.StartLine = Ysite;
                    break;
                }
            }
            else {
                Fork.StartLine = Ysite;
                break;
            }
        }
    }
    if ((Fork.ForkRightBorder[Ysite] - Fork.ForkLeftBorder[Ysite]) <= 2) {
        Fork.Peak.x = ForkScanStartCol;
        Fork.Peak.y = Fork.StartLine;
        return 1;
    }
    else
        return 0;
}


//三叉找拐点
uint8 ForkCheckInflexionPiont(void)
{
    if (ForkCheckPeakPiont()) {
        if (Base.firstroaderror >=3) {
            Fork.L_Inflexion.y = Base.firstroaderror - 3;
            Fork.L_Inflexion.x = Img.LeftBorder[Fork.L_Inflexion.y];
            Fork.R_Inflexion.y = Base.firstroaderror - 3;
            Fork.R_Inflexion.x = Img.RightBorder[Fork.R_Inflexion.y];
            return 1;
        }
        else {
            Fork.L_Inflexion.y = 0;
            Fork.L_Inflexion.x = LBorderCol;
            Fork.R_Inflexion.y = 0;
            Fork.R_Inflexion.x = RBorderCol;
            return 1;
        }
    }
    else
        return 0;
}
//进出完成标志
uint8 ForkCheckTurnOk(void)
{

}
//返回中线黑色部分的长度
uint8 ForkCheckUpPeakLenth(void)
{
    uint8 ForkUpPeakBlackCnt = 0;
    for(Ysite = Fork.Peak.y;Ysite < ROW;Ysite ++)
    {
        if(ImageUsed[ROW - 1 - Ysite][Fork.Peak.x] == BlackPoint)
            ForkUpPeakBlackCnt ++;
        if(ForkUpPeakBlackCnt >= RoadWide0)
            break;
    }
    Fork.CenterLineBlack = ForkUpPeakBlackCnt;
    return ForkUpPeakBlackCnt;
}


//规避十字误判 从30行向上搜索三岔顶边边缘 计算存在边缘的列数
uint8 Fork_Avoid_Cross(void)
{
    uint8 VaildCntColumn = 0;
    uint8 ColumnVaildX[128];
    for(Xsite = 34;Xsite < 94;Xsite ++)
    {
        for(Ysite = 30;Ysite < 55;Ysite ++)
        {
            if(ImageUsed[59 - Ysite][Xsite] == 0)
                break;
        }
        if(Ysite >= 55)
        {
            ColumnVaildX[Xsite] = 'T';
            if(ColumnVaildX[Xsite] == 'T')
                VaildCntColumn ++;
        }
        else
            ColumnVaildX[Xsite] = 'F';
//      if(VaildCntColumn >= 15)
//          break;
    }
    if(VaildCntColumn < 8)
    {
        return 1;
    }
    else
    {
        Fork.MaybeCorssFlag = 'T';
        return 0;
    }
}


//三岔参数表 向左发车时
uint32 ForkInfo[4][3] =
        {
                /*  方向    转入增益*10    转出增益*10 */
                {   'L'   ,      35      ,      32     },
                {   'R'   ,      35      ,      32     },
        };


//判断
//三岔
uint8 ForkJudge(void)
{
    Fork.PeakFindFlag = 'F';
    Fork.CenterLineBlack = 0;
    Fork.MaybeCorssFlag = 'F';
    //入三岔
    if (Fork.FindFlag == 'F' && Fork.state == ForkOut)
        if(ForkCheckInflexionPiont())
        {
            BeepTick(1,100);
            Fork.FindFlag = 'T';
            Fork.state = ForkInTurn;
            //记录 读取
            Fork.InDis = Wheel.Distance;
            Fork.ForkNum ++;
            Fork.In_Direct = ForkInfo[Fork.ForkNum - 1][0];
        }
    if(Fork.state == ForkInTurn) {
        ForkCheckInflexionPiont();
        if (ForkCheckTurnOk())
            Fork.state = ForkIn;
    }
    //出三岔
    if(Fork.state == ForkIn)
        if (ForkCheckInflexionPiont() && \
            Fork.ForkLenth <= (Wheel.Distance - Fork.InDis)) {
            Fork.state = ForkOutTurn;
            BeepTick(1,100);
        }
    if(Fork.state == ForkOutTurn) {
        ForkCheckInflexionPiont();
        if (ForkCheckTurnOk()) {
            Fork.state = ForkOut;
            Fork.FindFlag = 'F';
        }
    }
    return 1;
}

void ForkAddingLine(void)
{

}







//-------------------------------------车库-------------------------------------------------//
BarnTypedef     Barn;

//在车库内找斑马线//在中线列上找
uint8 BarnOutCheckZebraCrossing(void)
{
    uint8 ColorChangeCnt = 0;
//    uint8 ZebraCrossingCnt = 0;
//    uint8 ValidRow = 0;
    for(Ysite = 1;Ysite < RoadWide0 + 10;Ysite ++)
    {
        if ((ImageUsed[ROW - 1 - Ysite][CenterCol]==BlackPoint && ImageUsed[ROW - Ysite][CenterCol]==WhitePoint) || \
            (ImageUsed[ROW - 1 - Ysite][CenterCol]==WhitePoint && ImageUsed[ROW - Ysite][CenterCol]==BlackPoint))
            ColorChangeCnt++;
        if (ColorChangeCnt >= 8)
            break;
    }
//        Y0_ColorChange[Ysite] = 0;
//        for(Xsite = (64 - RoadWide0/2);Xsite < (Ysite + RoadWide0/2);Xsite ++)
//        {
//            if((ImageUsed[59 - Ysite][Xsite] == 0 && ImageUsed[59 - Ysite][Xsite - 1] == 255) ||
//                (ImageUsed[59 - Ysite][Xsite] == 0 && ImageUsed[59 - Ysite ][Xsite + 1] == 255) )
//            Y0_ColorChange[Ysite] ++;
//        }
//        if(Y0_ColorChange[Ysite] >= 6)
//        {
//            ValidRow ++;
//        }
//        if(ValidRow >= 5)
//            break;
    if(ColorChangeCnt >= 8)
        return 1;
    else
        return 0;
}

//在赛道上找斑马线//在RoadWide0/2行上找
uint8 BarnInCheckZebraCrossing(void)
{
    uint8 ColorChangeCnt = 0;
//    uint8 ZebraCrossingCnt = 0;
//    uint8 ValidRow = 0;
    for(Xsite = LBorderCol; Xsite < RBorderCol; Xsite ++)
    {
        if ((ImageUsed[ROW - 1 - RoadWide0/2][Xsite]==BlackPoint && ImageUsed[ROW - 1 - RoadWide0/2][Xsite + 1]==WhitePoint) || \
            (ImageUsed[ROW - 1 - RoadWide0/2][Xsite]==WhitePoint && ImageUsed[ROW - 1 - RoadWide0/2][Xsite + 1]==BlackPoint))
            ColorChangeCnt++;
        if (ColorChangeCnt >= 14)
            break;
    }
    for (Xsite = LBorderCol; Xsite < RBorderCol; Xsite++) {
        if ((ImageUsed[ROW - 1 - RoadWide0/2 + 3][Xsite]==BlackPoint && ImageUsed[ROW - 1 - RoadWide0/2 + 3][Xsite + 1]==WhitePoint) || \
            (ImageUsed[ROW - 1 - RoadWide0/2 + 3][Xsite]==WhitePoint && ImageUsed[ROW - 1 - RoadWide0/2 + 3][Xsite + 1]==BlackPoint))
            ColorChangeCnt++;
        if (ColorChangeCnt >= 14)
            break;
    }
    if(ColorChangeCnt >= 14)
        return 1;
    else
        return 0;
}
//出车库检查距正前方赛道边界的距离//出车库转向前直行使用//检查15-45行和左右边界列
uint8 BarnOutCheckBorderDistance(void)
{
    uint8 BarnOutRoadFindFlagL[100];
    uint8 BarnOutRoadFindFlagR[100];
    uint8 BarnOutBorderYsiteL = 255;
    uint8 BarnOutBorderYsiteR = 255;
    uint8 BarnOutBorderYsite = 255;
    BarnOutRoadFindFlagL[13] = 'F';
    BarnOutRoadFindFlagL[14] = 'F';
    BarnOutRoadFindFlagR[13] = 'F';
    BarnOutRoadFindFlagR[14] = 'F';
    for (Ysite = 15; Ysite < 45; Ysite++) {
        BarnOutRoadFindFlagL[Ysite] = 'F';
        BarnOutRoadFindFlagR[Ysite] = 'F';
        if (ImageUsed[ROW - 1 -Ysite][LBorderCol] == WhitePoint)
            BarnOutRoadFindFlagL[Ysite] = 'T';
        if (ImageUsed[ROW - 1 - Ysite][RBorderCol] == WhitePoint)
            BarnOutRoadFindFlagR[Ysite] = 'T';
        if (BarnOutRoadFindFlagL[Ysite - 2]=='T' && \
                BarnOutRoadFindFlagL[Ysite - 1]=='T' && \
                BarnOutRoadFindFlagL[Ysite]=='F' && \
                BarnOutBorderYsiteL == 255)
            BarnOutBorderYsiteL = Ysite;
        if (BarnOutRoadFindFlagR[Ysite - 2]=='T' && \
                BarnOutRoadFindFlagR[Ysite - 1]=='T' && \
                BarnOutRoadFindFlagR[Ysite]=='F' && \
                BarnOutBorderYsiteR == 255)
            BarnOutBorderYsiteR = Ysite;
        if (BarnOutBorderYsiteL!=255 && BarnOutBorderYsiteR!=255) {
            BarnOutBorderYsite = (BarnOutBorderYsiteL + BarnOutBorderYsiteR)/2;
            break;
        }
    }
    return BarnOutBorderYsite;
}
//入车库检查距正前方赛道边界的距离//入车库转向前直行使用//检查
uint8 BarnInCheckBorderDistance(void)
{

}
//出车库找拐点//找到斑马线后运行
uint8 BarnOutCheckInflexionPiont(void)
{

}

//进车库找车库拐点//找到斑马线后运行
uint8 BarnInCheckInflexionPiont(void)
{

}

//出车库检查出车库已完成
uint8 BarnOutCheckOk(void)
{

}

//入车库检查入库已完成//返回距车库边界距离
uint8 BarnInCheckOk(void)
{

}
//入库信息
uint16 BarnInInfo[2][6] =
        {
                /* 方向标识 识别起始行 识别后行驶距离cm 转向中线赋值   转向速度   转向完跑的距离*/
                {     'L'  ,   20     ,     20         ,    100      ,   230     ,    30   },
                {     'R'  ,   20     ,     15         ,    100      ,   230     ,    30   },
        };


//判断车库
void BarnJudge(void)
{
    ///////////////////////出库判断////////////////////////////
    if(Barn.FindFlag == 'F' && Barn.state == BarnStart
        //ElcProtect_Flag == 'T' && CarInfo.UpTime <= 0.3f && 。
            )
    {
        if (BarnOutCheckZebraCrossing()) {
            Barn.state = BarnOutStraight;
            Barn.FindFlag = 'T';
            BeepTick(1,100);
        }
    }
    if (Barn.state == BarnOutStraight) {
        if (BarnOutCheckBorderDistance() <= 40) {
            BeepTick(1, 50);
            Barn.state = BarnOutTurn;
        }
    }
    if (Barn.state == BarnOutTurn) {
        BarnOutCheckInflexionPiont();
        if (BarnOutCheckOk()){
            Barn.state = BarnOutOK;
            Barn.FindFlag = 'F';
            BeepTick(1, 100);
        }
    }
    if (CarInfo.UpTime >= 2.5f && Barn.state == BarnOutTurn) {//出库强制标志置位
        Barn.state = BarnOutOK;
        Barn.FindFlag = 'F';
        BeepTick(1, 100);
    }
    ///////////////////////入库判断////////////////////////////
    if(Barn.FindFlag == 'F' && Barn.state == BarnOutOK && CarInfo.UpTime >= 5.0f) {
        if (BarnInCheckZebraCrossing()){
            Barn.FindFlag = 'T';
            Barn.BarnNum ++;
            BeepTick(1,100);
            if(Barn.BarnNum == Barn.BranInNum) {//需要入库
                BarnInCheckInflexionPiont();
                Barn.state = BarnInStraight;
                Barn.BarnInTime = CarInfo.UpTime;
            }
            else//不需要入库
                Barn.state = BarnPass;
        }
    }
    //直接通过
//    if(Barn.state == BarnPass)
//    {
//        Barn.FindFlag = 'F';
//        Barn.state = BarnOutOK;
//        //清除环岛标志
//        Circle.CircleNum = 0;
//        Fork.ForkNum = 0;
//    }
    //允许转向
    if(Barn.state == BarnInStraight) {
        if (BarnInCheckBorderDistance() <= 40)
            Barn.state = BarnInTurn;
    }
    if (Barn.state == BarnInTurn) {
        BarnInCheckInflexionPiont();
        if (BarnInCheckOk()) {
            Barn.state = BarnInOK;
            BeepTick(3, 300);
        }
    }
    if (CarInfo.UpTime >= Barn.BarnInTime + 0.55f && Barn.state == BarnInTurn) {
        Barn.state = BarnInOK;
        BeepTick(2, 300);
    }
//    if (Barn.state == BarnInOK)
//        CarInfo.Protect_Flag ='T';
}

//出库补线
void BarnAddingLine(void)
{

}


//-------------------------------------环岛-------------------------------------------------//
CircleTypedef   Circle;


//环岛找补线的上拐点
uint8 Circle_Find_LeftUp_Inflexion(void)
{
    Circle.LeftUpInflexion.y = 0;
    Circle.LeftUpInflexion.x = 0;
    //右边界自下而上向左遍历得到的第一个点
    for(Ysite = max_ab(Base.firstleftlose.y + 2,7);Ysite < 59;Ysite ++)
    {
        for(Xsite = 125;Xsite > 0;Xsite --)
        {
            if(ImageUsed[59 - Ysite][Xsite] == 255 && \
                ImageUsed[59 - Ysite][Xsite - 1] == 255 && \
                ImageUsed[59 - Ysite][Xsite - 2] == 255)
                break;
        }
        for(;Xsite > 0;Xsite --)
        {
            if(ImageUsed[59 - Ysite][Xsite] == 0)
            {
                Circle.LeftUpInflexion.y = Ysite;
                Circle.LeftUpInflexion.x = Xsite;
                break;
            }
        }
        if(Circle.LeftUpInflexion.y != 0)
            break;
    }
    if(Circle.LeftUpInflexion.y == 0)
    {
        return 0;
    }
    else
        return 1;
}


//左环岛进入直道补线找的拐点
uint8  LeftCircleFindStraightInflexion(void)
{
    //在发生边缘左移前找到的最靠右的边缘点
    PosiType PointAfterBorderTurnLeft;
    uint8 LessthanMaxBorderCnt = 0;

    PointAfterBorderTurnLeft.x = 0;
    PointAfterBorderTurnLeft.y = 0;
    //记录最大值以及边缘左移的行列数
    for(Ysite = Base.firstleftnormal.y;Ysite < 55;Ysite ++)
    {
        if(Img.LeftBorder[Ysite] <= PointAfterBorderTurnLeft.x)
        {
            LessthanMaxBorderCnt ++;
        }
        if(LessthanMaxBorderCnt >= 3)
            break;
        if(Img.LeftBorder[Ysite] >= PointAfterBorderTurnLeft.x)
        {
            PointAfterBorderTurnLeft.x = Img.LeftBorder[Ysite];
            PointAfterBorderTurnLeft.y = Ysite;
            LessthanMaxBorderCnt = 0;
        }
    }
    Circle.LeftUpInflexion.x = PointAfterBorderTurnLeft.x;
    Circle.LeftUpInflexion.y = PointAfterBorderTurnLeft.y;
    return 0;
}


//环岛找补线的上拐点
uint8 Circle_Find_RightUp_Inflexion(void)
{
    Circle.RightUpInflexion.y = 0;
    Circle.RightUpInflexion.x = 0;
    //左边界自下而上向左遍历得到的第一个点
    for(Ysite = max_ab(Base.firstrightlose.y + 2,7);Ysite < 59;Ysite ++)
    {
        for(Xsite = 2;Xsite < 127;Xsite ++)
        {
            if(ImageUsed[59 - Ysite][Xsite] == 255 && \
                ImageUsed[59 - Ysite][Xsite + 1] == 255 && \
                ImageUsed[59 - Ysite][Xsite + 2] == 255)
                break;
        }
        for(;Xsite < 127;Xsite ++)
        {
            if(ImageUsed[59 - Ysite][Xsite] == 0)
            {
                Circle.RightUpInflexion.y = Ysite;
                Circle.RightUpInflexion.x = Xsite;
                break;
            }
        }
        if(Circle.RightUpInflexion.y != 0)
            break;
    }
    if(Circle.RightUpInflexion.y == 0)
        return 0;
    else
        return 1;
}


//右环岛进入直道补线找的拐点
uint8  RightCircleFindStraightInflexion(void)
{
    //在边缘右移前找到的最靠右的边缘点
    PosiType PointAfterBorderTurnRight;
    uint8 MorethanMinBorderCnt = 0;

    PointAfterBorderTurnRight.x = 127;
    PointAfterBorderTurnRight.y = 0;
    //记录最大值以及边缘右移的行列数
    for(Ysite = Base.firstrightnormal.y;Ysite < 55;Ysite ++)
    {
        if(Img.RightBorder[Ysite] >= PointAfterBorderTurnRight.x)
        {
            MorethanMinBorderCnt ++;
        }
        if(MorethanMinBorderCnt >= 3)
            break;
        if(Img.RightBorder[Ysite] <= PointAfterBorderTurnRight.x)
        {
            PointAfterBorderTurnRight.x = Img.RightBorder[Ysite];
            PointAfterBorderTurnRight.y = Ysite;
            MorethanMinBorderCnt = 0;
        }
    }
    Circle.RightUpInflexion.x = PointAfterBorderTurnRight.x;
    Circle.RightUpInflexion.y = PointAfterBorderTurnRight.y;
    return 0;
}


//向左边发车时的环岛大小以及位置
uint32 CircleInfo[][9] =
        {
                /*  方向  半径    中阈值    走一段拐    转向上点   转向k     转向速    环内速度  出环k  */
                {   'R' ,  50 ,    155  ,   0      ,   42   ,   35   ,   250   ,  240  ,  45   },
                {   'L' , 100 ,    105  ,   0      ,   41   ,   7    ,   250   ,  250  ,  15   },
//  {   'L' ,  65 ,    70   ,   0      ,   50   ,   25   ,   230   ,  240  ,  30   },
        };


//环岛判断
void CircleJudge(void)
{
    //电磁信号判断环岛
    if(ElcJudge() && Circle.FindFlag == 'F' && Wheel.Distance >= Circle.CircleEndDis)
    {
        uint8 InfoGroupx = 0;
        Circle.FindFlag = 'T';
        Circle.CircleNum ++;
        Circle.state = CircleInStraight;
        if(Barn.OutDir == 'L')
            InfoGroupx = Circle.CircleNum - 1;
        else if(Barn.OutDir == 'R')
            InfoGroupx = (Circle.CircleAmount - Circle.CircleNum);
        //读参数
        if(Barn.OutDir == 'L')
            Circle.dir = CircleInfo[InfoGroupx][0];
        else if(Barn.OutDir == 'R')
        {
            if( CircleInfo[InfoGroupx][0] == 'R')
                Circle.dir = 'L';
            else
                Circle.dir = 'R';
        }
        Circle.CircleR    = CircleInfo[InfoGroupx][1];
        Circle.CenterELC  = CircleInfo[InfoGroupx][2];
        Circle.TurnDis    = CircleInfo[InfoGroupx][3];
        Circle.TurnDis   /= 100;
        Circle.InTurnUP_Y = CircleInfo[InfoGroupx][4];
        Circle.InTurnK    = CircleInfo[InfoGroupx][5];
        Circle.InTurnK   /= 10;
        Circle.TurnSpeed  = CircleInfo[InfoGroupx][6];
        Circle.InSpeed    = CircleInfo[InfoGroupx][7];
        Circle.OutTurnK   = CircleInfo[InfoGroupx][8];
        Circle.OutTurnK  /= 10;
        //设置入环速度
        ExSpeed = Circle.FoundOutSpeed;
    }
    //环岛中央 标志置位 电磁
    if(Circle.FindFlag == 'T' && Circle.state == CircleInStraight && \
        (myabs(ElcCenter_23) <= 40 || myabs(ElcCenter_14) <= 15) && \
        ElcSum_23 > Circle.CenterELC && Wheel.Distance >= (Circle.DontELCJudgeDis))
    {
        Circle.state = CircleCenter;
        Circle.CenterDis = Wheel.Distance;
    }
    if(Circle.state == CircleCenter )//&& Wheel.Distance > (Circle.CenterDis + Circle.TurnDis))
    {
        Circle.state = CircleCouldInTurn;
    }
    //------------------------------------------------   左环判断  ---------------------------------------------------------//
    //入环左转开始
    if(Circle.FindFlag == 'T' && Circle.state == CircleCouldInTurn && \
        Circle.dir == 'L' && Line30_60.LeftNormal > 5 && \
        Line5_35.LeftLose >= 15 && LineALL.LeftLoseRightNormal >= 5 && \
        InRange(Base.firstleftnormal.y,25,Circle.InTurnUP_Y))
    {
        Circle.state = CircleInTurn;
        if(Circle.TurnSpeed == 0)
            CarInfo.ClosedLoopMode = DirectLoop;
        else
            ExSpeed = Circle.TurnSpeed;
        ICMIntegrate.Yaw_I_Enable = 'T';
        ICMIntegrate.TurnLeft_I = 0.00f;
        //BEEP_ON;
    }
    //入环左转完毕
    if((Circle.FindFlag == 'T' && Circle.state == CircleInTurn && \
        Circle.dir == 'L' && ICMIntegrate.TurnLeft_I > 25.0f && \
        Base.firstleftnormal.y <= 30) || \
        (Circle.FindFlag == 'T' && Circle.state == CircleInTurn && \
        Circle.dir == 'L' && ICMIntegrate.TurnLeft_I > 30.0f ) )
    {
        Circle.state = CircleIn;
        CarInfo.ClosedLoopMode = AllLoop;
        ExSpeed = Circle.InSpeed;
    }
    //出环岛左转
    if(Circle.FindFlag == 'T' && Circle.state == CircleIn && \
        Circle.dir == 'L' && Line5_35.LeftLose >= 20 &&  \
        LineALL.RightLose >= 10 && ICMIntegrate.TurnLeft_I > 250.0f)
    {
        Circle.state = CircleOutTurn;
        ICMIntegrate.TurnLeft_I = 0;
    }
    //完成出环左转
    if(Circle.FindFlag == 'T' && Circle.state == CircleOutTurn && \
        Circle.dir == 'L' && ICMIntegrate.TurnLeft_I > 25.000f)
    {
        ICMIntegrate.Yaw_I_Enable = 'F';
        Circle.state = CircleOutTurnOK;
        ExSpeed = Circle.FoundOutSpeed;
    }
    //出环再次经过环岛中心
    if(Circle.FindFlag == 'T' && Circle.state == CircleOutTurnOK && \
        Circle.dir == 'L' && ElcSum_14 >= Circle.CenterELC)
    {
        Circle.state = CircleOutStraight;
        //BEEP_OFF;
    }
    //出环完成环岛标志置位
    if(Circle.FindFlag == 'T' && Circle.state == CircleOutStraight && Circle.dir == 'L' \
        && ElcSum_14 <= Circle.CircleELC14 && Line5_35.LeftNormal >= 15 && Line5_35.RightNormal >= 15)
    {
        ExSpeed = NormalSpeed;
        BeepTick(1,100);
        Circle.state = CircleOut;
        Circle.FindFlag = 'F';
        Circle.CircleEndDis = (Wheel.Distance + Circle.DontELCJudgeDis);
    }
    //------------------------------------------------    右环判断   ---------------------------------------------------------//

    //入环右转开始
    if(Circle.FindFlag == 'T' && Circle.state == CircleCouldInTurn && \
        Circle.dir == 'R' && Line30_60.RightNormal > 5 && \
        Line5_35.RightLose >= 15 && LineALL.LeftNormalRightLose >= 5 && \
        InRange(Base.firstrightnormal.y,25,Circle.InTurnUP_Y))
    {
        //BEEP_ON;
        if(Circle.TurnSpeed == 0)
            CarInfo.ClosedLoopMode = DirectLoop;
        else
            ExSpeed = Circle.TurnSpeed;
        Circle.state = CircleInTurn;
        ICMIntegrate.Yaw_I_Enable = 'T';
        ICMIntegrate.TurnRight_I = 0.00f;
    }
    //入环右转完毕
    if((Circle.FindFlag == 'T' && Circle.state == CircleInTurn && \
        Circle.dir == 'R' && ICMIntegrate.TurnRight_I > 35.0f && \
        Base.firstrightnormal.y <= 30) || \
        (Circle.FindFlag == 'T' && Circle.state == CircleInTurn && \
        Circle.dir == 'R' && ICMIntegrate.TurnRight_I > 45.0f ))
    {
        Circle.state = CircleIn;
        CarInfo.ClosedLoopMode = AllLoop;
        ExSpeed = Circle.InSpeed;
    }
    //出环岛右转
    if(Circle.FindFlag == 'T' && Circle.state == CircleIn && \
        Circle.dir == 'R' && Line5_35.RightLose >= 20 &&  \
        LineALL.LeftLose >= 10 && ICMIntegrate.TurnRight_I > 250.0f
            )
    {
        Circle.state = CircleOutTurn;
        ICMIntegrate.TurnRight_I = 0;
    }
    //完成出环右转
    if(Circle.FindFlag == 'T' && Circle.state == CircleOutTurn && \
        Circle.dir == 'R' && ICMIntegrate.TurnRight_I > 30.000f && \
        Line30_60.RightNormal >= 7)
    {
        ICMIntegrate.Yaw_I_Enable = 'F';
        Circle.state = CircleOutTurnOK;
        ExSpeed = Circle.FoundOutSpeed;
    }
    //出环再次经过环岛中心
    if(Circle.FindFlag == 'T' && Circle.state == CircleOutTurnOK && \
        Circle.dir == 'R' && ElcSum_14 >= Circle.CenterELC )
    {
        Circle.state = CircleOutStraight;
        //BEEP_OFF;
    }
    //出环完成环岛标志置位
    if(Circle.FindFlag == 'T' && Circle.state == CircleOutStraight && Circle.dir == 'R' && \
        ElcSum_14 <= Circle.CircleELC14 && Line5_35.LeftNormal >= 15 && Line5_35.RightNormal >= 15)
    {
        ExSpeed = NormalSpeed;
        Circle.state = CircleOut;
        Circle.FindFlag = 'F';
        Circle.CircleEndDis = (Wheel.Distance + Circle.DontELCJudgeDis);
    }
}


//环岛补线
void CircleAddingLine(void)
{

}


//-------------------------------------坡道-------------------------------------------------//
//使用摄像头判断坡道后使用陀螺仪进行确认坡道
//否则摄像头标志清零
RampTypedef Ramp;


//计算满足斜率的左右行数
uint8 RampConfigSlope(void)
{

}


//判断电磁和陀螺仪联合判断
void RampJudge(void)
{
    //图像判断
    RampConfigSlope();
    if(((max_ab(Ramp.LeftSlopeSatisfy,Ramp.RightSlopeSatisfy) > 25 && \
        min_ab(Ramp.LeftSlopeSatisfy,Ramp.RightSlopeSatisfy) > 15 && \
        Base.LeftMax.y >= 55 && Base.RightMin.y >= 55) ||
        (Ramp.LeftSlopeSatisfy > 30 && LineALL.RightLose >= 25  && Base.LeftMax.y >= 55) || \
        (Ramp.RightSlopeSatisfy > 30 && LineALL.LeftLose >= 25  && Base.RightMin.y >= 55))&& \
        Ramp.FindFlag == 'F' && Ramp.RecoverFlag == 'F')
    {
        BeepTick(1,100);
        Ramp.MayRampFlag = 'T';
        Ramp.State = UpRamp;
        Ramp.MayRampDis = Wheel.Distance;
        ExSpeed = 230;
    }
    //图像预先标志后陀螺仪识别
    if(Ramp.MayRampFlag == 'T' && ICM_Treated.gyro.y > Ramp.MayRampGyroYMax)
    {
        //BEEP_ON;
        Ramp.FindFlag = 'T';
        CarInfo.ControlMode = ELCMODE;
        Ramp.UpRampDis = Wheel.Distance;
        Ramp.MayRampFlag = 'F';
    }//超过陀螺仪判断距离 清零标志
    else if(Ramp.MayRampFlag == 'T' && Wheel.Distance >= (Ramp.MayRampDis + Ramp.MayRampFlagClearDis))
    {
        Ramp.MayRampFlag = 'F';
        Ramp.State = EndRamp;
        ExSpeed =NormalSpeed;
    }
    //坡道结束 手动设置距离  一般1m
    if(Ramp.FindFlag == 'T' && Wheel.Distance > (Ramp.UpRampDis + 1.0) \
        && Ramp.RecoverFlag == 'F')
    {
        Ramp.State = DownRamp;
        Ramp.EndRampDis = Wheel.Distance;
        Ramp.RecoverFlag = 'T';
        ExSpeed = 210;
        Ramp.FindFlag = 'F';
    }
    //下坡道电磁稳定一段距离 陀螺仪下坡后采值不正确
    if(Ramp.RecoverFlag == 'T' && Wheel.Distance > (Ramp.EndRampDis + Ramp.RecoverDis))
    {
        //BEEP_OFF;
        Ramp.State = EndRamp;
        Ramp.RecoverFlag = 'F';
        ExSpeed = NormalSpeed;
        CarInfo.ControlMode = CAMMODE;
        Ramp.DontJudgeRampDis = Wheel.Distance + 2 * Ramp.RampLegth;
    }
}


//-------------------------------------------------十字-------------------------------------------------//

CrossTypedef Cross;
void clear_cross_flag()
{
    Cross.judge=1;
    Cross.FindFlag='F';
    Cross.state=CrossEnd;
    Cross.CrossLength=0.5;
}
//搜四个拐点
uint8 CrossCheckInflexionPoint(void)
{

}


//十字判别
void CrsosJudge(void)
{
    if( Cross.FindFlag == 'F' && CrossCheckInflexionPoint() == 1) {
        close_judge(2);
        Cross.FindFlag = 'T';
        Cross.state = CrossIn;
        BEEP_RING( 500);
        Cross.CrossStartDis = Wheel.Distance;
    }
    if((Cross.FindFlag == 'T' && Wheel.Distance > (Cross.CrossLength + Cross.CrossStartDis))) {

        Cross.FindFlag = 'F';
//        BeepTick(1, 100);
        Cross.state = CrossEnd;
        init_flag();


    }
}

void CrossAddingLine(void)
{

}






