g++ main.cpp -o a.exe -I /usr/include/opencv4
#x86_64-w64-mingw32-
