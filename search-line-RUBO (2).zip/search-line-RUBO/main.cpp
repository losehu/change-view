#include <bits/stdc++.h>
#include<opencv2/opencv.hpp>
#include "zf_common_headfile.h"
using namespace cv;
using namespace std;
Mat src;
void mouse_call_back(int event, int mouse_x, int mouse_y, int flags, void *userdata);
int main() {
    init_flag();
    fork_flag.cnt = 0;
   // init_img("C:/Users/Administrator/Desktop/github/chang-view/search-line-RUBO/9.bmp");
       init_img("C:\\Users\\Administrator\\Desktop\\github\\chang-view\\search-line-RUBO\\100.png");

       //flip(src, src, 1);
       uint8_t a[ROW][COL];
//    imshow("result", src);
//    for(int i=0;i<50;i++)
//        for(int j=0;j<50;j++)
//            src.at<unsigned char>(ROW-1-i,j)=255;
//    for(int i=0;i<5;i++)
//        for(int j=5;j<10;j++)
//            src.at<unsigned char>(ROW-1-i,j)=0;
       mat_to_v(src, a);
       uint8_t img[ROW][COL];
       for (int i = 0; i < ROW; i++)
           for (int j = 0; j < COL; j++)PerImg_ip[i][j] = &a[i][j];
       cvtColor(src, src, COLOR_GRAY2RGB);
       search_line_fork();
       GetBorder();
       solve_line();
       cal_middle_line();
       cout << "��ͨ��: " << connect.room << endl;
       for (int i = 0; i < ROW; i++) {
           draw(ROW - 1 - i, Img.LeftBorder[i], 4);
           draw(ROW - 1 - i, Img.RightBorder[i], 3);

       }
       imshow("result", src);
       waitKey(1);



    setMouseCallback("result", mouse_call_back, 0);
    waitKey(0);
}
void mouse_call_back(int event, int mouse_x, int mouse_y, int flags, void *userdata) {
    switch (event) {
        case EVENT_RBUTTONDOWN: {
            cout << mouse_x << '\t' << mouse_y << endl;
        }
        case EVENT_LBUTTONUP: {      //����ȡ����
            cout << Img.LeftBorderFindFlag[ROW - 1 - mouse_y] << '\t' << Img.RightBorderFindFlag[ROW - 1 - mouse_y]
                 << endl;
            cout << Img.LeftBorder[ROW - 1 - mouse_y] << '\t' << Img.RightBorder[ROW - 1 - mouse_y] << endl;
        }
    }
}


