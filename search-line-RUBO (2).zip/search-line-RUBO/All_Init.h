//
// Created by Administrator on 2022/3/14.
//

#ifndef MAIN_CPP_ALL_INIT_H
#define MAIN_CPP_ALL_INIT_H

#include "zf_common_headfile.h"
#include "RUBO_stack.h"

void All_Init(void);

#endif //MAIN_CPP_ALL_INIT_H
