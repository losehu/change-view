#include <bits/stdc++.h>
#include<opencv2/opencv.hpp>
#include"ty.h"

using namespace cv;
using namespace std;

bool flag = false;
Mat src;
int test_flag = 1;   //0����͸�ӱ任  1��ȡ����
int val1;
int cnt = 0;
float point[4][2];

//ͼƬ���� ���ͼ�� ���ͼ�� ���������붥������ �������ر߳� �����ϱ߽��������� �����±߽��������� x31 x41 x11 x21
//# 1.bmp 100 100 85 16 46 65 85 113 88 110
void mouse_call_back(int event, int mouse_x, int mouse_y, int flags, void *userdata);

void show();

bool command_flag = 0;
string path = "../";
string path_end;
int point_center_x;
int point_center_y = 85;//0~high_end
int see_len = 16;
int x31,
        x41,
        x11, y11
, x21, y21,
        x12, y12,
        x22, y22;

int main() {




    cout << "ʹ��ǰȷ��ͼ���д��ڷ�������У׼,����ͼƬ�о��У�����" << endl;

    while (1) {
        // path = "../";

       // cout << "������ͼƬ����:";
     //   cin >> path_end;
        if (path_end[0] == '#') {
            command_flag = 1;
            cin >> path_end >> width_end >> high_end >> point_center_y >> see_len >> y11 >> y21 >> point[0][0]
                >> point[1][0] >> point[2][0] >> point[3][0];

        }
        path = path_end;
path="../TEST11.bmp";
        src = imread(path);
        if (src.empty()) {
            cout << "����ͼƬ·��!" << endl;
            continue;
        }
        width = src.cols;
        high = src.rows;
        cvtColor(src, src, COLOR_RGB2GRAY, 0);
        if (!command_flag) {
            width_end=188;
            high_end=120;
            point_center_y=55;
            see_len=60;
//         //   cout << "���ͼ��:";
//            cin >> width_end;
//        //    cout << "���ͼ��:";
//            cin >> high_end;
//            cout << "���������붥������:";
//            cin >> point_center_y;
//            cout << "�������ر߳�:";
//            cin >> see_len;
        }

        if (command_flag) {
            point_center_x = width_end / 2;
            namedWindow("ԭͼ", 0);
            resizeWindow("ԭͼ", 320, 240);

            imshow("ԭͼ", src);
            show();
        } else {
            cout << "������Ҽ�������ӷ�������-����-����-����ѡȡ�ĸ���:" << endl;
            waitKey(1500);
            point_center_x = width_end / 2;
            namedWindow("ԭͼ", 0);
            resizeWindow("ԭͼ", 320, 240);

            imshow("ԭͼ", src);
            setMouseCallback("ԭͼ", mouse_call_back, 0);
            waitKey(0);
        }
    }
}

void mouse_call_back(int event, int mouse_x, int mouse_y, int flags, void *userdata) {
    switch (event) {
        case EVENT_RBUTTONDOWN: {
            int flag_cnt = 4;
            if (test_flag) {
                point[cnt][0] = mouse_x;
                point[cnt][1] = mouse_y;
                cout << "ѡ�У�" << mouse_x << '\t' << mouse_y << endl;
//                flag_cnt = 4;
//                point[0][0]=61,point[0][1]=49;
//                point[1][0]=128,point[1][1]=51;
//                point[2][0]=74,point[2][1]=23;
//                point[3][0]=113,point[3][1]=24;
//                ѡ�У�61        49
//                ѡ�У�128       51
//                ѡ�У�74        23
//                ѡ�У�113       24
            } else flag_cnt = 1;
            cnt++;
            if (cnt == flag_cnt) {
                start:

                vector<Point2f> src_coners(4);
                int y31,y41;
                x31 = point[0][0],
                x41 = point[1][0],
                x11 = point[2][0], y11 = point[2][1],y21=point[3][1];
                x21 = point[3][0], y31 = point[0][1],y41=point[1][1];

                x12 = point_center_x - see_len / 2, y12 = point_center_y - see_len / 2,
                x22 = point_center_x + see_len / 2, y22 = point_center_y + see_len / 2;
/*
 *         (x11,y11)******************(x21,y11)            (x12,y12)**************(x22,y12)
 *                *                   *                             *            *
 *              *       ԭͼ�����Σ�      *         -------->         * ����������Σ�*
 *             *                          *                         *            *
 *   (x31,y21)******************************(x41,y21)      (x12,y22)**************(x22,y22)
 *   test_flag=1ʱ��(�����ֵ㣬��X31��ʼ����ʱ����Ĵ�)                  �������Լ��ڴ������޸ģ�   ---->    ����ӡ���ľ���������
 *   test_flag=0ʱ��                              �Ҽ�ͼƬ�鿴Ч��
 *
 *
 */

                src_coners[0] = Point2f(x31, y31);
                src_coners[1] = Point2f(x41, y41);
                src_coners[2] = Point2f(x11, y11);
                src_coners[3] = Point2f(x21, y21);


                vector<Point2f> dst_coners(4);
                dst_coners[0] = Point2f(x12, y22);
                dst_coners[1] = Point2f(x22, y22);
                dst_coners[2] = Point2f(x12, y12);
                dst_coners[3] = Point2f(x22, y12);
                Mat warpMatrix;
                warpMatrix = getPerspectiveTransform(src_coners, dst_coners);


                /*********͸�ӱ任_OPENCV****************/
                /*      Mat dst;
                      warpPerspective(src, dst, warpMatrix, dst.size());
                      imshow("opencv", dst);*/
                /*********͸�ӱ任_C****************/

                double change_Mat[3][3];
                for (int i = 0; i < 3; i++)
                    for (int j = 0; j < 3; j++)
                        change_Mat[i][j] = warpMatrix.at<double>(i, j);
                num_type src_tmp1[high][width];
                double change_un_Mat[3][3];
                for (int i = 0; i < high; i++)
                    for (int j = 0; j < width; j++)
                        src_tmp1[i][j] = src.at<uchar>(i, j);


                Mat un_warpMatrix;     //�����
                if (test_flag) {
                    invert(warpMatrix, un_warpMatrix, DECOMP_LU);
                    cout << "�����" << endl << un_warpMatrix << endl;
                } else {
                    un_warpMatrix = (cv::Mat_<double>(3, 3)
                            << 1.009090909090906, -0.5518999868056464, 4.176474468927346,
                            -2.025649951715763e-16, 0.1625676210581866, 3.295289616044348,
                            -5.264385651077164e-18, -0.006102388177859869, 0.876302942340677);
                }

                for (int i = 0; i < 3; i++)
                    for (int j = 0; j < 3; j++)
                        change_un_Mat[i][j] = un_warpMatrix.at<double>(i, j);
                unsigned char *b[high_end][width_end];
                /******************ָ���ַӳ��*******************/
                unsigned char back_color = 255;
                for (int i = 0; i < width_end; i++) {
                    for (int j = 0; j < high_end; j++) {
                        int local_x = (int) ((change_un_Mat[0][0] * i + change_un_Mat[0][1] * j + change_un_Mat[0][2]) /
                                             (change_un_Mat[2][0] * i + change_un_Mat[2][1] * j + change_un_Mat[2][2]));
                        int local_y = (int) ((change_un_Mat[1][0] * i + change_un_Mat[1][1] * j + change_un_Mat[1][2]) /
                                             (change_un_Mat[2][0] * i + change_un_Mat[2][1] * j + change_un_Mat[2][2]));
                        if (local_x >= 0 && local_y >= 0 && local_y < high && local_x < width) {
                            b[j][i] = &src_tmp1[local_y][local_x];
                        } else b[j][i] = &back_color;
                    }
                }

                /**********�����ȡָ��ֵ&��ʾͼƬ***********************/
                //    Mat src1 ;
                Mat src1;
                src1 = (Mat::ones(high_end, width_end, CV_8U));
                unsigned char bb[high_end][width_end];//ͼ
                memset(bb, 0, sizeof(bb));
                for (int i = 1; i < high_end - 1; i++)
                    for (int j = 1; j < width_end - 1; j++)
                        bb[i][j] = *b[i][j];
                for (int i = 0; i < high_end; i++)
                    for (int j = 0; j < width_end; j++)
                        src1.at<uchar>(i, j) = bb[i][j];
                // inRange(src1, Scalar(10), Scalar(255), src1);
                namedWindow("���ͼ", 0);
                resizeWindow("���ͼ", 342, 300);

                imshow("���ͼ", src1);
                cout << "ת���ɹ�!!" << endl;

                cout<<"ָ���ʽ:"<<endl;
                cout<<"# ͼƬ���� ���ͼ�� ���ͼ�� ���������붥������ �������ر߳� �����ϱ߽��������� �����±߽��������� ��������X���� ��������X���� ��������X���� ��������X����"<<endl;
                cout << "���ָ��:" << endl;
                cout << "# " << path_end << " " << width_end << " " << high_end << " " << point_center_y << " "
                     << see_len << " " << y11 << " " << y21 << " " << point[0][0] << " " << point[1][0] << " "
                     << point[2][0] << " " << point[3][0] << endl;

                waitKey();
                return;
            }
            break;
        }
        case EVENT_LBUTTONUP: {      //����ȡ����
            if (flag) {
                val1 = src.at<Vec3b>(mouse_y, mouse_x)[0];
                //   val2 =image.at<Vec3b>(y, x)[1];
                //   val3 = image.at<Vec3b>(y, x)[2];
                cout << val1 << endl;
                Mat result;
                //     inRange(src, Scalar(0), Scalar(val1), result);
                namedWindow("���ͼ", 0);
                resizeWindow("���ͼ", 342, 300);

                imshow("���ͼ", result);
            }
            flag = 0;
            break;
        }
    }
}

void show() {
    vector<Point2f> src_coners(4);
    x31 = point[0][0],
    x41 = point[1][0],
    x11 = point[2][0], y11 = y11,
    x21 = point[3][0], y21 = y21,
    x12 = point_center_x - see_len / 2, y12 = point_center_y - see_len / 2,
    x22 = point_center_x + see_len / 2, y22 = point_center_y + see_len / 2;
/*
 *         (x11,y11)******************(x21,y11)            (x12,y12)**************(x22,y12)
 *                *                   *                             *            *
 *              *       ԭͼ�����Σ�      *         -------->         * ����������Σ�*
 *             *                          *                         *            *
 *   (x31,y21)******************************(x41,y21)      (x12,y22)**************(x22,y22)
 *   test_flag=1ʱ��(�����ֵ㣬��X31��ʼ����ʱ����Ĵ�)                  �������Լ��ڴ������޸ģ�   ---->    ����ӡ���ľ���������
 *   test_flag=0ʱ��                              �Ҽ�ͼƬ�鿴Ч��
 *
 *
 */

    src_coners[0] = Point2f(x31, y21);
    src_coners[1] = Point2f(x41, y21);
    src_coners[2] = Point2f(x11, y11);
    src_coners[3] = Point2f(x21, y11);


    vector<Point2f> dst_coners(4);
    dst_coners[0] = Point2f(x12, y22);
    dst_coners[1] = Point2f(x22, y22);
    dst_coners[2] = Point2f(x12, y12);
    dst_coners[3] = Point2f(x22, y12);
    Mat warpMatrix;
    warpMatrix = getPerspectiveTransform(src_coners, dst_coners);


    /*********͸�ӱ任_OPENCV****************/
    /*      Mat dst;
          warpPerspective(src, dst, warpMatrix, dst.size());
          imshow("opencv", dst);*/
    /*********͸�ӱ任_C****************/

    double change_Mat[3][3];
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            change_Mat[i][j] = warpMatrix.at<double>(i, j);
    num_type src_tmp1[high][width];
    double change_un_Mat[3][3];
    for (int i = 0; i < high; i++)
        for (int j = 0; j < width; j++)
            src_tmp1[i][j] = src.at<uchar>(i, j);


    Mat un_warpMatrix;     //�����
    if (test_flag) {
        invert(warpMatrix, un_warpMatrix, DECOMP_LU);
        cout << "�����" << endl << un_warpMatrix << endl;
    } else {
        un_warpMatrix = (cv::Mat_<double>(3, 3)
                << 1.009090909090906, -0.5518999868056464, 4.176474468927346,
                -2.025649951715763e-16, 0.1625676210581866, 3.295289616044348,
                -5.264385651077164e-18, -0.006102388177859869, 0.876302942340677);
    }

    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            change_un_Mat[i][j] = un_warpMatrix.at<double>(i, j);
    unsigned char *b[high_end][width_end];
    /******************ָ���ַӳ��*******************/
    unsigned char back_color = 0;
    for (int i = 0; i < width_end; i++) {
        for (int j = 0; j < high_end; j++) {
            int local_x = (int) ((change_un_Mat[0][0] * i + change_un_Mat[0][1] * j + change_un_Mat[0][2]) /
                                 (change_un_Mat[2][0] * i + change_un_Mat[2][1] * j + change_un_Mat[2][2]));
            int local_y = (int) ((change_un_Mat[1][0] * i + change_un_Mat[1][1] * j + change_un_Mat[1][2]) /
                                 (change_un_Mat[2][0] * i + change_un_Mat[2][1] * j + change_un_Mat[2][2]));
            if (local_x >= 0 && local_y >= 0 && local_y < high && local_x < width) {
                b[j][i] = &src_tmp1[local_y][local_x];
            } else b[j][i] = &back_color;
        }
    }

    /**********�����ȡָ��ֵ&��ʾͼƬ***********************/
    //    Mat src1 ;
    Mat src1;
    src1 = (Mat::ones(high_end, width_end, CV_8U));
    unsigned char bb[high_end][width_end];//ͼ
    memset(bb, 0, sizeof(bb));
    for (int i = 1; i < high_end - 1; i++)
        for (int j = 1; j < width_end - 1; j++)
            bb[i][j] = *b[i][j];
    for (int i = 0; i < high_end; i++)
        for (int j = 0; j < width_end; j++)
            src1.at<uchar>(i, j) = bb[i][j];
    // inRange(src1, Scalar(10), Scalar(255), src1);
    namedWindow("���ͼ", 0);
    resizeWindow("���ͼ", 342, 300);

    imshow("���ͼ", src1);
    cout << "ת���ɹ�!!" << endl;


     cout << "���ָ��:" << endl;
    cout << "# " << path_end << " " << width_end << " " << high_end << " " << point_center_y << " " << see_len << " "
         << y11 << " " << y21 << " " << point[0][0] << " " << point[1][0] << " " << point[2][0] << " " << point[3][0]
         << endl;
    cout<<"ָ���ʽ:"<<endl;
    cout<<"# ͼƬ���� ���ͼ�� ���ͼ�� ���������붥������ �������ر߳� �����ϱ߽��������� �����±߽��������� ��������X���� ��������X���� ��������X���� ��������X����"<<endl;

    waitKey();
    return;
}